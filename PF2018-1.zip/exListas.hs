-- Exemplo Listas

somaLista :: [Int] -> Int
somaLista [] = 0
somaLista (a:x) = a + somaLista x