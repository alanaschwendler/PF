-- Exercicios Prova 1
-- exs.hs

iSort :: [Int] -> [Int]
iSort [] = []
iSort (a:x) = ins a (iSort x)

ins :: Int -> [Int] -> [Int]
ins a [] = [a]
ins a (b:x)
 | a <= b = a:(b:x)
 | otherwise = b: ins a x

primeiro :: [Int] -> Int
primeiro [] = error "Lista vazia não tem primeiro elemento.."
primeiro (x:xs) = x

ultimo :: [Int] -> Int
ultimo [x] = x
ultimo (x:xs) = ultimo xs

maiorMenor :: [Int] -> (Int, Int)
maiorMenor [] = error "Lista vazia"
maiorMenor (x:xs) =  (primeiro (iSort xs), ultimo (iSort xs)) 