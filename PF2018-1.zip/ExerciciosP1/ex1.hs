-- Exercicios Prova 1
-- ex1.hs

-- Lista 1
quatroIguais:: Int -> Int -> Int -> Int -> Bool
quatroIguais a b c d
 | a == b && b == c && c == d = True
 | otherwise = False