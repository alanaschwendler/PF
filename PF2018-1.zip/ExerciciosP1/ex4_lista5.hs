-- Lista 5
-- ex4_lista5.hs

membroNum :: [Int] -> Int -> Int
membroNum [] n = 0
membroNum (x:xs) n
 | x == n = 1 + membroNum xs n
 | otherwise = membroNum xs n 

unico :: [Int] -> [Int]
unico [] = []
unico (x:xs)
 | (membroNum xs x) == 1 = x : []
 | otherwise = unico xs