-- Lista 5
-- ex2_lista5.hs

membroNum :: [Int] -> Int -> Int
membroNum [] n = 0
membroNum (x:xs) n
 | x == n = 1 + membroNum xs n
 | otherwise = membroNum xs n 