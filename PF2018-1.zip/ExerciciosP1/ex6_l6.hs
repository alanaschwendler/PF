-- Lista 6
-- ex6_l6.hs

pegaMaiores :: Int -> [a] -> [a]
pegaMaiores n [] = error "Lista vazia"
pegaMaiores n (x:xs)
