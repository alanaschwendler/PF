separaLinha :: String -> [String]
separaLinha [] = error "string vazia"
separaLinha (takeWhile /= '\n' (x:xs)) 