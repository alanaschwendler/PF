-- Lista 4
-- ex2.hs

tamanho :: [Int] -> Int
tamanho [] = 0
tamanho (x:xs) = (tamanho xs) + 1  