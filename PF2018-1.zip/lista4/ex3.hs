-- Lista 4
-- ex3.hs

produtoLista :: [Int] -> Int
produtoLista [] = 1
produtoLista (x:xs) = (produtoLista xs) * x