-- Lista 4
-- ex5.hs

concatLista :: [[Int]] ->[Int]
concatLista [[], []] = []
concatLista [[a], [a]] = [a] : concatLista[[a], [a]]