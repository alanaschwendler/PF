-- Lista 4
-- ex1.hs

dobraLista :: [Int] -> [Int]
dobraLista [] = []
dobraLista (x:xs) = (x * 2) : (dobraLista xs)