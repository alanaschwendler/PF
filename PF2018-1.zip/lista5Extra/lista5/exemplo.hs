-- Exemplo

ins :: Int -> [Int] -> [Int]
ins n [] = n:[]
ins n (x:xs)
 | n <= x = n:x:xs
 | otherwise = x:ins n xs

insertionSort :: [Int] -> [Int]
insertionSort [] = []
insertionSort (x:xs) = ins x (insertionSort xs)

--

menores ::  Int -> [Int] -> [Int]
menores n (x:xs) 
 | n > x = x
 | otherwise = menores n xs




--quickSort :: [Int] -> [Int]
--quickSort [] = []
--quickSort (x:xs) = quickSort (menores x xs) ++ [x] ++ (maiores x xs)
