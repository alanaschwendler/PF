-- Lista 5
-- ex2.hs

membroNum :: [Int] -> Int -> Int
membroNum [] _ = 0
membroNum (x:xs) n 
 | x == n = membroNum xs n + 1
 | otherwise = membroNum xs n