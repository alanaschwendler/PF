-- Lista 5
-- ex3.hs

verifica :: [Int] -> Int -> Int
verifica [] _ = 0
verifica (x:xs) n 
 | x == n = (verifica xs n) + 1
 | otherwise = verifica xs n 

unico :: [Int] -> [Int]
unico [] = []
unico list@(x:xs) 
 | (verifica list x) > 1 = unico (elimina x xs) -- se o elemento aparece mais de uma vez, ele é removido e continua testando sem este elemento
 | otherwise = x:(unico xs) -- se estava apenas uma vez na lista original, fixa o elemento na lista e testa pro resto 

elimina :: Int -> [Int] -> [Int]
elimina n [] = []
elimina n (x:xs) 
 | n == x = elimina n xs
 | otherwise = x : elimina n xs 