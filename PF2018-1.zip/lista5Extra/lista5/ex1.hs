-- Lista 5
-- ex1.hs

membro :: [Int] -> Int -> Bool
membro [] _ = False
membro (x:xs) n
 | x == n = True
 | otherwise = membro xs n  