-- Lista Extra
-- ex2.hs

pegaPosicao :: Int -> [Int] -> Int
pegaPosicao _ [] = error "**Lista vazia**"
pegaPosicao n (x:xs) 
 | 