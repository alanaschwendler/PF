-- Lista extra
-- ex1.hs

retornaUltimo :: [a] -> a
retornaUltimo [] = error "**Lista vazia**"
retornaUltimo [x] = x
retornaUltimo (x:xs) = retornaUltimo xs